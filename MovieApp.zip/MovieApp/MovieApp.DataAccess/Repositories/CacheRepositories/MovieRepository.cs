﻿using MovieApp.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MovieApp.DataAccess.Repositories.CacheRepositories
{
    public class MovieRepository : IRepository <Movie>
    {

        public List<Movie> GetAll()
        {
            return CacheDb.Movies;
         }

        public Movie GetById(int Id)
        {
            return CacheDb.Movies.SingleOrDefault(x => x.Id == Id);
        }

        public int Insert(Movie entity)
        {
            CacheDb.MovieId++;
            entity.Id = CacheDb.MovieId;
            CacheDb.Movies.Add(entity);
            return entity.Id;
        }

        public void Update(Movie entity)
        {
            Movie movie = CacheDb.Movies.SingleOrDefault(x => x.Id == entity.Id);
            if (movie != null)
            {
                int index = CacheDb.Movies.IndexOf(movie);
                CacheDb.Movies[index] = entity;
            }
        }
        public void DeleteById(int Id)
        {
            Movie movie = CacheDb.Movies.SingleOrDefault(x => x.Id == Id);
            if (movie != null)
                CacheDb.Movies.Remove(movie);
        }
    }
}
