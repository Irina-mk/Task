﻿using MovieApp.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MovieApp.DataAccess.Repositories.CacheRepositories
{
    public class PersonRepository : IRepository<Person>
    {

        public List<Person> GetAll()
        {
          return CacheDb.People;
        }
        public Person GetById(int Id)
        {
           return CacheDb.People.SingleOrDefault(x => x.Id == Id);
        }


        public int Insert(Person entity)
        {

            CacheDb.PersonId++;
            entity.Id = CacheDb.PersonId;
            CacheDb.People.Add(entity);
            return entity.Id;

         }

        public void Update(Person entity)
        {
            Person person = CacheDb.People.SingleOrDefault(x => x.Id == entity.Id);
            if (entity != null)
            {
                int index = CacheDb.People.IndexOf(person);
                CacheDb.People[index] = entity;
            }
        }
        public void DeleteById(int Id)
        {
            Person person = CacheDb.People.SingleOrDefault(x => x.Id == Id);
            if (person != null)
                CacheDb.People.Remove(person);
        }
    }
}
