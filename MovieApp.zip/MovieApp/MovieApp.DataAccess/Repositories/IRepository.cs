﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieApp.DataAccess.Repositories
{
   public interface IRepository<T>
    {
        //CRUD 

        T GetById(int Id);
        List<T> GetAll();
        int Insert(T entity);
        void Update(T entity);
        void DeleteById(int Id);

    }
}
