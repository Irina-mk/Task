﻿using MovieApp.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MovieApp.DataAccess
{
   public static class CacheDb
    {

        public static List<Movie> Movies;
        public static List<Person> People;

        public static int MovieId;
        public static int PersonId;


        static CacheDb()
        {
            People = new List<Person>()
            {
                new Person()
                {
                    Id = 1,
                    FullName = "Bob Bobsky",
                     Address = "Narodni heroi 4",
                    Phone = 07888886666,
                    Role = Domain.Enums.Roles.Actor


                },
                new Person()
                {
                    Id = 2,
                    FullName = "Kent Clark",
                     Address = "Debarska ulica 5",
                    Phone = 084563175554,
                    Role = Domain.Enums.Roles.Director
                },
                      new Person()
                {
                    Id = 3,
                    FullName = "Rasputin Janackovski",
                     Address = "Kosturski heroi 1",
                    Phone = 07856525865,
                    Role = Domain.Enums.Roles.AllOfTheAbove
                  },
            };


            Movies = new List<Movie>()
            {
                new Movie()
                {
                    Id = 1,
                    Title = "Pulp Fiction",
                    Duration = 152,
                    PublishDate = new DateTime(1994, 7, 15, 3, 15, 0),
                    Genre = Domain.Enums.Genres.Action,
                    PersonId = 1,

                    
                    

            },
                 new Movie()
                {
                    Id = 2,
                    Title = "Requiem for a Dream",
                    Duration = 102,
                    PublishDate = new DateTime(2022, 6, 01, 3, 15, 0),
                    Genre = Domain.Enums.Genres.Comedy,
                    PersonId = 2



            },
                     new Movie()
                {
                    Id = 3,
                    Title = "Trainspotting",
                    Duration = 93,
                    PublishDate = new DateTime(1997, 9, 22, 3, 15, 0),
                     Genre = Domain.Enums.Genres.Fantasy,
                     PersonId = 3,

            }
            };
            MovieId = 3;
            PersonId = 3;

        }









    }
}
