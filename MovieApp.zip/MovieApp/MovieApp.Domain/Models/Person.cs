﻿using MovieApp.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace MovieApp.Domain.Models
{
    public class Person
    {
        public int Id { get; set; }
        public string FullName { get; set; }
         public string Address { get; set; }
        public long Phone { get; set; }

        public Roles Role { get; set; }
        public int MovieId { get; set; }

        public List<Movie> Movies{ get; set; }







    }
}
