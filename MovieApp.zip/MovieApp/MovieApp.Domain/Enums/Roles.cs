﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieApp.Domain.Enums
{
    public enum Roles
    {
        Actor = 1, 
        Director, 
        Producer, 
        AllOfTheAbove
    }
}
