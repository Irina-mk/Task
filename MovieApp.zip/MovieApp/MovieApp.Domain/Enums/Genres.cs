﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieApp.Domain.Enums
{
    public enum Genres
    {
        Drama = 1,
        Comedy,
        Action,
        Fantasy,
        Horror
    }
}
