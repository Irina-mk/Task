﻿using MovieApp.DataAccess.Repositories;
using MovieApp.DataAccess.Repositories.CacheRepositories;
using MovieApp.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MovieApp.Services.Services
{
    public class PesonService : IUserService

    {
        private IRepository<Person> _personRepository;
        public PesonService()
        {
            _personRepository = new PersonRepository();
        }
        public int AddNewPerson(Person entity)
        {
            return _personRepository.Insert(entity);
        }

        public string GetLastPesonName()
        {
            return _personRepository.GetAll().LastOrDefault().FullName;
        }

        public Person GetUserById(int id)
        {
            return _personRepository.GetById(id);
        }
    }
}
