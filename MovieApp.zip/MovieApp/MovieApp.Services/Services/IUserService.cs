﻿using MovieApp.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MovieApp.Services.Services
{
   public interface IUserService
    {
        Person GetUserById(int id);
        int AddNewPerson(Person entity);
        string GetLastPesonName();
       
    }
}
