﻿using MovieApp.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MovieApp.Services.Services
{
    public interface IMovieService
    {

        List<Movie> GetAllMovies();
        Movie GetMovieById(int id);
        int GetMoiveCount();
        





    }
}
