﻿using MovieApp.DataAccess.Repositories;
using MovieApp.DataAccess.Repositories.CacheRepositories;
using MovieApp.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MovieApp.Services.Services
{
    public class MovieService : IMovieService
    {
        private IRepository<Movie> _movieRepository;
        public MovieService()
        {
            _movieRepository = new MovieRepository();
        }



        public List<Movie> GetAllMovies()
        {
           return _movieRepository.GetAll();
         }

        public int GetMoiveCount()
        {
            return _movieRepository.GetAll().Count; 
         }

        public Movie GetMovieById(int id)
        {
            return _movieRepository.GetById(id);
         }
    }
}
