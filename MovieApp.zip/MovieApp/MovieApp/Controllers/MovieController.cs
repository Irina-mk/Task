﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MovieApp.DataAccess;
using MovieApp.Domain.Models;
using MovieApp.Models;

namespace MovieApp.Controllers
{
    public class MovieController : Controller
    {
        [Route("all-books")]
        public ActionResult Index()
        {
            List<Movie> movies = CacheDb.Movies;
            return View(movies);
        }

        // GET: MovieController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: MovieController/Create
        public IActionResult Create()
        {
            MovieCreateViewModel model = new MovieCreateViewModel();
            return View(model);
        }
        [HttpPost]
        public IActionResult Create(MovieCreateViewModel model)
        {
            Movie movie = new Movie();
            int id = CacheDb.Movies.Count() + 1;
            Person person = new Person();
            if (model != null)
            {
                movie.Id = id;
                movie.Title = model.Title;
                movie.Genre = model.Genre;
                movie.PublishDate = model.PublishDate;
                person.FullName =model.FullName;
                  movie.Person = person;
                movie.Duration = model.Duration;
                CacheDb.Movies.Add(movie);

            }
            return RedirectToAction("Index");
        }

     
        // GET: MovieController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: MovieController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: MovieController/Delete/5
        public ActionResult Delete(int id)
        {
            var res = CacheDb.Movies.Where(x => x.Id == id).First();
            CacheDb.Movies.Remove(res);
            List<Movie> movies = CacheDb.Movies;

            return View("Index", movies);
        }

        
    }
}
