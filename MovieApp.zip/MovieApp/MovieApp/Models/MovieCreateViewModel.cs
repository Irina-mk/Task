﻿

using MovieApp.Domain.Enums;
using MovieApp.Domain.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Security.Permissions;
using System.Threading.Tasks;

namespace MovieApp.Models
{
    public class MovieCreateViewModel
    {
        public string Title { get; set; }
        [Display(Name = "Duration")]
        public int Duration { get; set; }
        [Display(Name = "Creator's full name")]
        public string FullName { get; set; }
        
        [Display(Name = "Publish Date")]
        public DateTime PublishDate { get; set; }
        public Genres Genre { get; set; }

    }
}



 
