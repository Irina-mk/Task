﻿using MovieApp.Domain.Enums;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MovieApp.Models
    
    
 {
    public class MovieEditViewModel
    {
        public int Id { get; set; }
         public string Title { get; set; }
        [Display(Name = "Creator's fullname")]
        public string PersonFirstName { get; set; }
        public string PersonLastName { get; set; }
        [Display(Name = "Duration")]
        public int Duration { get; set; }
        public Genres Genre { get; set; }


    }
}
